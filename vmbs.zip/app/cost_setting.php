<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cost_setting extends Model
{
    //
    protected $fillable=['id','percent_dev'];
}
