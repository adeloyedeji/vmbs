<?php
namespace App\Repositories\Interfaces;

interface UtilityInterface 
{
	public function getCountry($id);
}