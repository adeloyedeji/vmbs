<?php
namespace App\Repositories\Interfaces;

interface CompanyInterface 
{
	
	public function getCompany($id);
}