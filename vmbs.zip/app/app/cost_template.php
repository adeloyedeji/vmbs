<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cost_template extends Model
{
    //
    protected $fillable= ['operator_id','level','name','production','field_id','license'];
}
