<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class operator extends Model
{
    //
    protected $fillable=['rc_num',  'name',  'canonial_name',  'address'];
 }
