<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fdp extends Model
{
    //
    protected $fillable= ['operator_id','type','terrain','level','name'];
}
