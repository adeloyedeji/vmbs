<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cost_code extends Model
{
    //
}
