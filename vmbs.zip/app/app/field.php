<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class field extends Model
{
    //
    protected $fillable=['field_name','block_id',' zone_name ','terrain_name','technical_allowable'];
 }
