<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fdp_doc extends Model
{
    //
    protected $fillable=['title',  'operator_id',   'status',  'path' ];
}
