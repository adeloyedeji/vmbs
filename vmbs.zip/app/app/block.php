<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class block extends Model
{
    //
    protected $fillable=['blockname','water_depth','area'];
}
