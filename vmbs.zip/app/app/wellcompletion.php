<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class wellcompletion extends Model
{
    //
}
