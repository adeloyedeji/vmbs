<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cost_data extends Model
{
    //
}
