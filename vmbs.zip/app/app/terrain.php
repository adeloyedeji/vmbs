<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class terrain extends Model
{
    //
    protected $fillable=['name','zone'];
}
