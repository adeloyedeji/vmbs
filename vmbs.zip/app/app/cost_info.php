<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cost_info extends Model
{
    //
    protected $fillable=['EF','CE','DF','CD','ETR','IRR','NCF'];
}
